package com.example.voiceassistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.accessibility.AccessibilityEvent
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.util.Locale

// ---------- 1. मुख्य Activity: आवाज़ सुनना और कमांड चलाना ----------
class MainActivity : AppCompatActivity(), RecognitionListener {

    // अपने असिस्टेंट का नाम यहाँ बदलें (छोटे अक्षरों में)
    private val wakeWords = listOf("jarvis", "जार्विस", "केशा", "kesha")

    private lateinit var recognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private var torchOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE),
            1
        )
        tts = TextToSpeech(this) { tts.language = Locale("hi", "IN") }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(this)
        listen()
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        recognizer.startListening(i)
    }

    override fun onResults(results: Bundle?) {
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()?.lowercase() ?: ""
        val wake = wakeWords.firstOrNull { text.contains(it) }
        if (wake != null) handle(text.substringAfter(wake).trim())
        listen() // लगातार सुनते रहो
    }

    override fun onError(error: Int) {
        Handler(Looper.getMainLooper()).postDelayed({ listen() }, 700)
    }

    private fun say(msg: String) = tts.speak(msg, TextToSpeech.QUEUE_FLUSH, null, null)

    // ---------- 2. कमांड हैंडलर ----------
    private fun handle(cmd: String) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val acc = VoiceAccessibilityService.instance
        when {
            cmd.contains("open") || cmd.contains("खोल") -> {
                val name = cmd.replace("open", "").replace("खोलो", "").replace("खोल", "").trim()
                openApp(name)
            }
            cmd.contains("call") || cmd.contains("कॉल") -> {
                val number = cmd.filter { it.isDigit() }
                if (number.isNotEmpty() &&
                    checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                ) {
                    startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))
                } else say("नंबर नहीं मिला")
            }
            cmd.contains("torch") || cmd.contains("flashlight") || cmd.contains("टॉर्च") -> {
                val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                torchOn = !torchOn
                cm.setTorchMode(cm.cameraIdList[0], torchOn)
            }
            cmd.contains("volume up") || cmd.contains("आवाज़ बढ़ा") ->
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            cmd.contains("volume down") || cmd.contains("आवाज़ कम") ->
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            cmd.contains("wifi") || cmd.contains("वाईफाई") ->
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            cmd.contains("home") || cmd.contains("होम") -> acc?.goHome()
            cmd.contains("back") || cmd.contains("पीछे") -> acc?.goBack()
            cmd.contains("recent") || cmd.contains("रीसेंट") -> acc?.showRecents()
            cmd.contains("notification") || cmd.contains("नोटिफिकेशन") -> acc?.showNotifications()
            cmd.contains("screenshot") || cmd.contains("स्क्रीनशॉट") -> acc?.screenshot()
            cmd.startsWith("click") || cmd.startsWith("दबाओ") || cmd.startsWith("टैप") -> {
                val target = cmd.substringAfter(" ", "").trim()
                if (acc?.clickByText(target) != true) say("बटन नहीं मिला")
            }
            cmd.startsWith("type") || cmd.startsWith("लिखो") -> {
                val t = cmd.substringAfter(" ", "").trim()
                if (acc?.typeText(t) != true) say("लिखने की जगह नहीं मिली")
            }
            cmd.contains("scroll down") || cmd.contains("नीचे") -> acc?.scroll(true)
            cmd.contains("scroll up") || cmd.contains("ऊपर") -> acc?.scroll(false)
            // उदाहरण: "jarvis whatsapp 919876543210 hello kaise ho"
            cmd.startsWith("whatsapp") || cmd.startsWith("व्हाट्सऐप") -> {
                val parts = cmd.split(" ").drop(1)
                val number = parts.firstOrNull()?.filter { it.isDigit() } ?: ""
                val msg = parts.drop(1).joinToString(" ")
                if (number.isEmpty()) { say("नंबर बताइए"); return }
                val uri = Uri.parse("https://wa.me/$number?text=" + Uri.encode(msg))
                startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
                // WhatsApp खुलने का इंतज़ार करके Send दबाओ
                Handler(Looper.getMainLooper()).postDelayed({
                    acc?.clickByDescription("Send")
                }, 3500)
            }
            else -> say("मुझे समझ नहीं आया")
        }
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(name)
        }
        val intent = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (intent != null) startActivity(intent) else say("ऐप नहीं मिला")
    }

    // ज़रूरी खाली फ़ंक्शन
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(p: Bundle?) {}
    override fun onEvent(t: Int, p: Bundle?) {}
    override fun onDestroy() { recognizer.destroy(); super.onDestroy() }
}

// ---------- 3. Accessibility Service: फ़ोन का "पूरा कंट्रोल" ----------
class VoiceAccessibilityService : AccessibilityService() {
    companion object { var instance: VoiceAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }

    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun showRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun showNotifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun screenshot() = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    // स्क्रीन पर लिखे टेक्स्ट वाला बटन दबाओ
    fun clickByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findAccessibilityNodeInfosByText(text).firstOrNull() ?: return false
        return clickNode(node)
    }

    // बटन के content description (जैसे "Send") से दबाओ
    fun clickByDescription(desc: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return findByDesc(root, desc)?.let { clickNode(it) } ?: false
    }

    private fun findByDesc(n: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        if (n.contentDescription?.toString().equals(desc, ignoreCase = true)) return n
        for (i in 0 until n.childCount) {
            n.getChild(i)?.let { c -> findByDesc(c, desc)?.let { return it } }
        }
        return null
    }

    private fun clickNode(start: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = start
        while (n != null) {
            if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }

    // जिस बॉक्स में कर्सर है उसमें टेक्स्ट लिखो
    fun typeText(text: String): Boolean {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // स्क्रॉल
    fun scroll(down: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: return false
        return node.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            n.getChild(i)?.let { c -> findScrollable(c)?.let { return it } }
        }
        return null
    }

    // स्क्रीन पर किसी भी x,y जगह टैप
    fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(g, null, null)
    }
}
