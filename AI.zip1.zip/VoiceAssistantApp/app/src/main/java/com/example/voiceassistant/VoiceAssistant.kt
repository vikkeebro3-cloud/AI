package com.example.voiceassistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity(), RecognitionListener {

    // असिस्टेंट के नाम (छोटे अक्षरों में) - यहाँ बदल सकते हैं
    private val wakeWords = listOf(
        "jarvis", "jarwis", "jarvish", "जार्विस", "जर्विस", "जारविस", "जार्विश",
        "kesha", "केशा", "केशा"
    )

    // हिंदी नाम -> ऐप का अंग्रेज़ी नाम
    private val aliases = mapOf(
        "यूट्यूब" to "youtube", "यूटूब" to "youtube",
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सएप" to "whatsapp",
        "क्रोम" to "chrome", "कैमरा" to "camera", "सेटिंग्स" to "settings",
        "सेटिंग" to "settings", "इंस्टाग्राम" to "instagram", "मैप्स" to "maps",
        "मैप" to "maps", "गैलरी" to "gallery", "फोन" to "phone", "गूगल" to "google"
    )

    private lateinit var recognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var contBtn: Button
    private val handler = Handler(Looper.getMainLooper())
    private var torchOn = false
    private var continuous = false
    private var oneShot = false
    private var ready = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        status = TextView(this).apply { textSize = 20f; text = "तैयार" }
        val speakBtn = Button(this).apply {
            text = "🎤 बोलिए (एक कमांड, नाम बोलना ज़रूरी नहीं)"
            setOnClickListener { oneShot = true; startListening() }
        }
        contBtn = Button(this).apply {
            text = "लगातार सुनना: बंद"
            setOnClickListener {
                continuous = !continuous
                text = if (continuous) "लगातार सुनना: चालू (पहले नाम बोलें)" else "लगातार सुनना: बंद"
                if (continuous) { oneShot = false; startListening() } else recognizer.cancel()
            }
        }
        val accBtn = Button(this).apply {
            text = "Accessibility चालू करें"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(status)
        root.addView(speakBtn)
        root.addView(contBtn)
        root.addView(accBtn)
        setContentView(root)

        tts = TextToSpeech(this) { tts.language = Locale("hi", "IN") }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            show("इस फ़ोन में आवाज़ पहचान नहीं है। Play Store से 'Google' ऐप अपडेट करें।")
            return
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(this)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            ready = true
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE), 1
            )
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        ready = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        show(if (ready) "तैयार। 'बोलिए' दबाएँ" else "माइक की अनुमति ज़रूरी है")
    }

    private fun show(msg: String) { status.text = msg }

    private fun say(msg: String) {
        show(msg)
        tts.speak(msg, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    private fun startListening() {
        if (!ready) { show("पहले माइक की अनुमति दें"); return }
        recognizer.cancel()
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
        }
        recognizer.startListening(i)
        show(if (oneShot) "सुन रहा हूँ... बोलिए" else "सुन रहा हूँ... पहले नाम बोलें")
    }

    override fun onResults(results: Bundle?) {
        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
        val text = list.firstOrNull()?.lowercase() ?: ""
        show("सुना: $text")
        val wake = wakeWords.firstOrNull { text.contains(it) }
        val cmd = if (wake != null) text.substringAfter(wake).trim() else text.trim()
        if (oneShot || wake != null) {
            if (cmd.isEmpty()) {
                say("जी, बोलिए")
                oneShot = true
            } else {
                oneShot = false
                handle(cmd)
            }
        }
        if (continuous) handler.postDelayed({ startListening() }, 1200)
    }

    override fun onError(error: Int) {
        if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            show("एरर कोड: $error")
        }
        if (continuous && error != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            handler.postDelayed({ startListening() }, 1200)
        }
    }

    private fun needAcc(): VoiceAccessibilityService? {
        val a = VoiceAccessibilityService.instance
        if (a == null) say("पहले Accessibility चालू करें")
        return a
    }

    private fun handle(cmd: String) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when {
            cmd.startsWith("whatsapp") || cmd.startsWith("व्हाट्सऐप") || cmd.startsWith("व्हाट्सएप") -> {
                val parts = cmd.split(" ").drop(1)
                val number = parts.firstOrNull()?.filter { it.isDigit() } ?: ""
                val msg = parts.drop(1).joinToString(" ")
                if (number.isEmpty()) { say("नंबर बताइए"); return }
                val uri = Uri.parse("https://wa.me/$number?text=" + Uri.encode(msg))
                startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
                handler.postDelayed({ VoiceAccessibilityService.instance?.clickByDescription("Send") }, 3500)
            }
            cmd.contains("open") || cmd.contains("ओपन") || cmd.contains("खोल") -> openApp(cmd)
            cmd.contains("call") || cmd.contains("कॉल") -> {
                val number = cmd.filter { it.isDigit() }
                if (number.isNotEmpty() &&
                    checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                ) {
                    startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))
                } else say("नंबर नहीं मिला या कॉल की अनुमति नहीं है")
            }
            cmd.contains("torch") || cmd.contains("flashlight") || cmd.contains("टॉर्च") || cmd.contains("फ्लैश") -> {
                try {
                    val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    torchOn = !torchOn
                    cm.setTorchMode(cm.cameraIdList[0], torchOn)
                    show(if (torchOn) "टॉर्च चालू" else "टॉर्च बंद")
                } catch (e: Exception) { say("टॉर्च नहीं चली") }
            }
            cmd.contains("volume up") || cmd.contains("आवाज़ बढ़ा") || cmd.contains("आवाज बढ़ा") || cmd.contains("वॉल्यूम बढ़ा") ->
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            cmd.contains("volume down") || cmd.contains("आवाज़ कम") || cmd.contains("आवाज कम") || cmd.contains("वॉल्यूम कम") ->
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            cmd.contains("wifi") || cmd.contains("वाईफाई") || cmd.contains("वाई-फाई") ->
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            cmd.contains("home") || cmd.contains("होम") -> needAcc()?.goHome()
            cmd.contains("back") || cmd.contains("पीछे") || cmd.contains("बैक") -> needAcc()?.goBack()
            cmd.contains("recent") || cmd.contains("रीसेंट") -> needAcc()?.showRecents()
            cmd.contains("notification") || cmd.contains("नोटिफिकेशन") -> needAcc()?.showNotifications()
            cmd.contains("screenshot") || cmd.contains("स्क्रीनशॉट") -> needAcc()?.screenshot()
            cmd.contains("scroll down") || cmd.contains("नीचे") -> needAcc()?.scroll(true)
            cmd.contains("scroll up") || cmd.contains("ऊपर") -> needAcc()?.scroll(false)
            cmd.startsWith("click") || cmd.startsWith("दबाओ") || cmd.startsWith("टैप") -> {
                val target = cmd.substringAfter(" ", "").trim()
                val a = needAcc() ?: return
                if (!a.clickByText(target)) say("बटन नहीं मिला")
            }
            cmd.startsWith("type") || cmd.startsWith("लिखो") -> {
                val t = cmd.substringAfter(" ", "").trim()
                val a = needAcc() ?: return
                if (!a.typeText(t)) say("लिखने की जगह नहीं मिली")
            }
            else -> say("समझ नहीं आया: $cmd")
        }
    }

    private fun openApp(cmd: String) {
        var n = cmd
        aliases.forEach { (k, v) -> n = n.replace(k, v) }
        listOf("open", "ओपन", "खोलो", "खोल", "करो", "कर दो", "दो").forEach { n = n.replace(it, "") }
        n = n.trim()
        if (n.isEmpty()) { say("कौन सा ऐप?"); return }
        val pm = packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(n)
        }
        val intent = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (intent != null) {
            show("खोल रहा हूँ: $n")
            startActivity(intent)
        } else say("ऐप नहीं मिला: $n")
    }

    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(p: Bundle?) {}
    override fun onEvent(t: Int, p: Bundle?) {}
    override fun onDestroy() {
        if (::recognizer.isInitialized) recognizer.destroy()
        super.onDestroy()
    }
}

// ---------- Accessibility Service: फ़ोन का कंट्रोल ----------
class VoiceAccessibilityService : AccessibilityService() {
    companion object { var instance: VoiceAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }

    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun showRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun showNotifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun screenshot() = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    fun clickByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findAccessibilityNodeInfosByText(text).firstOrNull() ?: return false
        return clickNode(node)
    }

    fun clickByDescription(desc: String): Boolean {
        val root = rootInActiveWindow ?: return false
        return findByDesc(root, desc)?.let { clickNode(it) } ?: false
    }

    private fun findByDesc(n: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        if (n.contentDescription?.toString().equals(desc, ignoreCase = true)) return n
        for (i in 0 until n.childCount) {
            n.getChild(i)?.let { c -> findByDesc(c, desc)?.let { return it } }
        }
        return null
    }

    private fun clickNode(start: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = start
        while (n != null) {
            if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }

    fun typeText(text: String): Boolean {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(down: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root) ?: return false
        return node.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            n.getChild(i)?.let { c -> findScrollable(c)?.let { return it } }
        }
        return null
    }

    fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(g, null, null)
    }
}
